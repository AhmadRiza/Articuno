package com.riza.example.articuno.utils;

public class ENV {

    public static final String BASE_URL="https://uas-mobile.herokuapp.com/api";


}
